// Application      Curran Grades
// Author:          Spencer Curran
// Description:     creates a file that displays 15 grades and gives the average of those grades
// Version:         1.0
// Date modified:   April 8
package curran.grades;
import java.util.Scanner;
import java.util.Random;
import java.io.*;

public class CurranGrades {
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        // Create file and open it
        FileWriter gradeFile = new FileWriter("/Users/scurran/Desktop/StudentGrades.txt", true);
        PrintWriter outputGrades = new PrintWriter(gradeFile);
        // setting up an array for grades to be displayed in the output file
        Random randomNumbers = new Random();
        int grades[];
        grades = new int[15];
        //loop through grades assigning random grade values to each slot
        for(int i = 0; i < grades.length; i++)
        {
            grades[i] = randomNumbers.nextInt(101);    
        }
        // displaying grades in the output file
        outputGrades.println("grade 1 is: " + grades[0]);
        outputGrades.println("grade 2 is: " + grades[1]);
        outputGrades.println("grade 3 is: " + grades[2]);
        outputGrades.println("grade 4 is: " + grades[3]);
        outputGrades.println("grade 5 is: " + grades[4]);
        outputGrades.println("grade 6 is: " + grades[5]);
        outputGrades.println("grade 7 is: " + grades[6]);
        outputGrades.println("grade 8 is: " + grades[7]);
        outputGrades.println("grade 9 is: " + grades[8]);
        outputGrades.println("grade 10 is: " + grades[9]);
        outputGrades.println("grade 11 is: " + grades[10]);
        outputGrades.println("grade 12 is: " + grades[11]);
        outputGrades.println("grade 13 is: " + grades[12]);
        outputGrades.println("grade 14 is: " + grades[13]);
        outputGrades.println("grade 15 is: " + grades[14]);
        
        
        // formula for average grades and displaying to the output file
        int sumGrades;
        sumGrades = grades[0] + grades[1] + grades[2] + grades[3] + grades [4] + grades [5] + grades [6] + grades [7] + grades [8] + grades [9] + grades [10] + grades [11] + grades [12] + grades [13] + grades [14];
        int avgGrades;
        avgGrades = sumGrades/15;
        // outputting totals
        outputGrades.println("=====================================");
        outputGrades.println("You have 15 grades");
        outputGrades.println("Your grade sum is " + sumGrades);
        outputGrades.println("Your grade average is: " + avgGrades);
        // close output file
        outputGrades.close();
        File myFile = new File("/Users/scurran/Desktop/StudentGrades.txt");
        Scanner inputGrades = new Scanner(myFile);
       // read the data from file
       while (inputGrades.hasNext()) {
           String gradeContents = inputGrades.nextLine();
           System.out.println(gradeContents);    
       }
       // close file
       inputGrades.close();
        
        
        
    }
    
}
