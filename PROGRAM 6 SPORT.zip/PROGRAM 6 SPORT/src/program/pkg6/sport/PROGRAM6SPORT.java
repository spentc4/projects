// Application      Fools Ball
// Author:          Spencer Curran
// Description:     Shows rules, asks how many rounds the user wants to play, randomizes a game and determines the victor
// Version:         1.0
// Date modified:   March 27
package program.pkg6.sport;
import java.util.Scanner;
import java.util.Random;
import java.util.stream.*;

public class PROGRAM6SPORT {

    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Welcome to foolsball, the only rule is to get the ball in the other team's basket.");
        System.out.println("Only a fool would ever dare play this game, hence the name.");
        System.out.println("how many rounds would you like to play?");
        // Turning on randomizer and Keyboard
        Scanner keyboard = new Scanner(System.in);
        Random random = new Random();
        int userInput = keyboard.nextInt();
        //Setting up arrays for each team
        int[] score1;
        score1 = new int[userInput];
        int[] score2;
        score2 = new int[userInput];
        //loop to assign a random value to team one for however many rounds the user chose to play
        for(int i = 0; i < score1.length; i++)
        {
            score1[i] = random.nextInt(11);
            System.out.println(score1[i]);
            
        }
        System.out.println("^These are the scores of team 1");
        //loop to assign a random value to team two for however many rounds the user chose to play
        for(int j = 0; j < score2.length; j++)
        {
            score2[j] = random.nextInt(11);
            System.out.println(score2[j]);
            
        }
        System.out.println("^These are the scores of team 2");
        //determines the total score of team 1
        int sum1 = IntStream.of(score1).sum();
        System.out.println("Team 1 scored " + sum1);
        //determines the total score of team 2
        int sum2 = IntStream.of(score2).sum();
        System.out.println("Team 2 scored " + sum2);
        //conditions for win loss or tie
        if (sum1 > sum2)
            System.out.println("Team 1 won");
        
        if (sum2 > sum1)
            System.out.println("Team 2 won");
        
        if (sum1 == sum2)
            System.out.println("Both teams tied, play again for a tiebreaker");
        

        
        
        
        
       





         
    }
    }

