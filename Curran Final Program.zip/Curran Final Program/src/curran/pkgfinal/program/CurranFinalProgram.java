// Application      Final Project: Adventures of Brownlee
// Author:          Spencer Curran
// Description:     Follow the directions and try to get to the end
// Version:         1.0
// Date modified:   May 2 2019
package curran.pkgfinal.program;

import java.io.IOException;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.*;

public class CurranFinalProgram {

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        try {
            FileWriter fw = new FileWriter("/Users/scurran/Desktop/adventuresBrownlee.txt", true);
            PrintWriter outputFile = new PrintWriter(fw);

            System.out.println("Welcome to Adventures in Brownlee Hall\n");
            System.out.println("Select a starting place to begin.");
            Scanner keyboard = new Scanner(System.in);
            int menuStart;
            do {
                System.out.println("1) Brownlee Basement Weightroom");
                System.out.println("2) Bike room");
                System.out.println("3) Brownlee Bug");
                System.out.println("4) Suicide");

                menuStart = keyboard.nextInt();
// Declaration of all of my methods that correspond to the various menu choices, I used if statements to execute the different methods
// outputs all of the selections to a text document "map"
                outputFile.println("You typed..." + menuStart);
                outputFile.close();
                if (menuStart == 1) {
                    BBWFunction();
                }

                if (menuStart == 2) {
                    bikeRoomFunction();
                }

                if (menuStart == 3) {
                    brownleeBugFunction();
                }

            } while (menuStart != 4);

        } catch (FileNotFoundException error) {
            System.out.println("Sorry this file lacks exsistence");
            System.out.println("Error Message " + error.getMessage());

        } catch (EOFException error) {
            System.out.println("Sorry I cant find that junk");
            System.out.println("Error message " + error.getMessage());
        } finally {
            System.out.println("We are finished using your dumb files.");
        }
    }
// method for the Brownlee Basement Weightroom selection

    public static void BBWFunction() throws IOException {
        try {
            FileWriter fw = new FileWriter("/Users/scurran/Desktop/adventuresBrownlee.txt", true);
            PrintWriter outputFile = new PrintWriter(fw);
            System.out.println("Hello, welcome to the basement, my name is steve and I will be your guide through the depths of Brownlee");
            System.out.println("Your first task is you have to pick which method you want to take to get to the first floor");
            Scanner keyboard = new Scanner(System.in);
            int menuBBW;
            // loop for a menu to make another decision
            do {
                System.out.println("1) the stairs\n");
                System.out.println("2) walk outside and come in the main entrance\n");
                System.out.println("3) walk into the bike room\n");
                System.out.println("4) suicide\n");

                menuBBW = keyboard.nextInt();
                outputFile.println("You typed..." + menuBBW);
                outputFile.close();
                if (menuBBW == 1) {
                    bikeRoomFunction();
                }
                if (menuBBW == 2) {
                    System.out.println("you don't have your card to scan into the building, you freeze to death and die.");
                    System.exit(0);
                    // system.exit statements terminate the program which means you die
                }
                if (menuBBW == 3) {
                    System.out.println("There is a murderer in the bike room, you are killed with a hachet.");
                    System.exit(0);
                }
                if (menuBBW == 4) {
                    System.out.println("You have committed suicide.");
                    System.exit(0);
                }
            } while (menuBBW != 1);

        } catch (FileNotFoundException error) {
            System.out.println("Sorry this file lacks exsistence");
            System.out.println("Error Message " + error.getMessage());

        } catch (EOFException error) {
            System.out.println("Sorry I cant find that junk");
            System.out.println("Error message " + error.getMessage());
        } finally {
            System.out.println("We are finished using your dumb files.");
        }
    }

    public static void bikeRoomFunction() throws IOException {
        try {
            FileWriter fw = new FileWriter("/Users/scurran/Desktop/adventuresBrownlee.txt", true);
            PrintWriter outputFile = new PrintWriter(fw);
            System.out.println("You find a guy in a mask carrying a hachet. \n");
            System.out.println("Mask guy: 'If you can answer this question I won't kill you.");
            System.out.println("Mask guy: 'What is my favorite color?'");
            System.out.println("1) 'green'\n");
            System.out.println("2) 'grey'\n");
            System.out.println("3) 'black'\n");
            System.out.println("4) 'Please dont kill me'\n");
            Scanner keyboard = new Scanner(System.in);
            int maskGuyQuestion;
            maskGuyQuestion = keyboard.nextInt();
            // outputs selections made to the "map" file already created
            outputFile.println("You typed..." + maskGuyQuestion);
            outputFile.close();
            if (maskGuyQuestion == 1) {
                brownleeBugFunction();
            }

            if (maskGuyQuestion == 2) {
                System.out.println("'Who's favorite color is grey, thats dumb. Youre dead !'");
                System.out.println("he kills you with his hachet and you die.");
                System.exit(0);
            }
            if (maskGuyQuestion == 3) {
                System.out.println("'Black is not my favorite color.'");
                System.out.println("He sprints towards you and kills you with his hachet.");
                System.exit(0);
            }
            if (maskGuyQuestion == 4) {
                System.out.println("'I really want to kill you so I will.'");
                System.out.println("You die of a heart attack, the killer doesn't even touch you");
                System.exit(0);

            }
        } catch (FileNotFoundException error) {
            System.out.println("Sorry this file lacks exsistence");
            System.out.println("Error Message " + error.getMessage());

        } catch (EOFException error) {
            System.out.println("Sorry I cant find that junk");
            System.out.println("Error message " + error.getMessage());
        } finally {
            System.out.println("We are finished using your dumb files.");

        }
    }

    public static void brownleeBugFunction() throws IOException {
        try {
            FileWriter fw = new FileWriter("/Users/scurran/Desktop/adventuresBrownlee.txt", true);
            PrintWriter outputFile = new PrintWriter(fw);
            System.out.println("You've made it, this is the most challenging of the rooms.");
            // loop to display the 3 by 3 grid of numbers for the final question
            int[][] board = new int[3][3];
            for (int i = 0; i < board.length; i++) {
                for (int j = 0; j < board[i].length; j++) {
                    board[i][j] = i + j;
                }
            }
            for (int[] a : board) {
                for (int i : a) {
                    System.out.print(i + "\t");
                }
                System.out.println("\n");
            }

            System.out.println("what is the sum of all of these numbers");
            System.out.println("1) 19");
            System.out.println("2) 18");
            System.out.println("3) 17");
            Scanner keyboard = new Scanner(System.in);
            int bugAnswer;
            bugAnswer = keyboard.nextInt();
            // outputs all of your selections into a file for you to look back at to figure out the path.
            outputFile.println("You typed..." + bugAnswer);
            outputFile.println("This is the path you took through brownlee. ^");
            outputFile.println("you can use this path again, or you can choose a different one next time, hope you had fun !");
            outputFile.close();
            if (bugAnswer == 1) {
                System.out.println("you came all this way just to answer the last question incorrectly, sad.");
                System.out.println("you die.");
                System.exit(0);
            }
            if (bugAnswer == 2) {
                System.out.println("congratulations you have made it out of brownlee alive");
                System.out.println("heres the detonator of brownlee. Type in how many seconds you want to count down from.");
                // initiating a countdown determined by the user
                int countDown;
                countDown = keyboard.nextInt();
                while (countDown > -1) {
                    System.out.println("Counting down... " + countDown);
                    countDown--;
                }
                System.out.println("Kaboom, you have successfully made it out of brownlee and destroyed the killer.");
                System.exit(0);
            }
            if (bugAnswer == 3) {
                System.out.println("so close, you lost.");
                System.exit(0);
            }

        } catch (FileNotFoundException error) {
            System.out.println("Sorry this file lacks exsistence");
            System.out.println("Error Message " + error.getMessage());

        } catch (EOFException error) {
            System.out.println("Sorry I cant find that junk");
            System.out.println("Error message " + error.getMessage());
        } finally {
            System.out.println("We are finished using your dumb files.");
        }
    }

}
